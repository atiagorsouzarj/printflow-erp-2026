#!/bin/bash
export PATH="/usr/local/node/bin:$PATH"
export NODE_ENV=production
cd /www/wwwroot/erp-grafica
npm start
