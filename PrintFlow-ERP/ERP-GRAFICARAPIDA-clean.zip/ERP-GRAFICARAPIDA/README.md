# PrintFlow ERP

ERP fullstack para gráfica rápida, papelaria personalizada, impressão 3D e brindes.

## Stack
Next.js App Router, React, TypeScript, PostgreSQL, Drizzle ORM e Tailwind CSS.

## Desenvolvimento
1. Configure `DATABASE_URL` em `.env`.
2. Instale dependências com `npm install`.
3. Aplique o schema com `npx drizzle-kit push`.
4. Defina `ADMIN_SETUP_TOKEN` com pelo menos 32 caracteres.
5. Execute `npm run dev`.
6. Acesse `/primeiro-acesso` para criar o primeiro administrador; depois use `/login`.

## Rotas centrais
- `/materiais`: estoque e compras
- `/impressoras`: custos de equipamentos
- `/produtos`: ficha técnica e precificação
- `/pre-cadastros`: captação multicanal
- `/crm`: clientes PF/PJ
- `/orcamentos`: propostas
- `/kanban`: produção
- `/pdv`: venda e cupom
- `/whatsapp` e `/email`: automações
- `/relatorios`: gestão
- `/configuracoes`: Painel de Controle e segurança
- `/logistica`: entregas e expedição
- `/impressao-producao`: etiquetas térmicas, ordem A4 e PDFs
- `/acompanhar/[token]`: acompanhamento público seguro
- `/login`: autenticação administrativa
- `/cadastro`: captação pública

Consulte `docs/ARCHITECTURE.md` antes de alterar fluxos, preços ou integrações.
